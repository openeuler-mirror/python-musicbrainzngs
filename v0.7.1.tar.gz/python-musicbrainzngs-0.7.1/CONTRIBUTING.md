# Contribute

1. Fork the [repository](https://github.com/alastair/python-musicbrainzngs>)
   on Github.
2. Make and test whatever changes you desire.
3. Signoff and commit your changes using ``git commit -s``.
4. Send a pull request.
